<?php 
include 'db_connect.php'; 

if (isset($_GET['reg_no'])) {
    $reg_no = $_GET['reg_no'];

    // First delete related records
    $conn->query("DELETE FROM attendance WHERE student_reg_no = '$reg_no'");
    $conn->query("DELETE FROM results WHERE student_reg_no = '$reg_no'");
    $conn->query("DELETE FROM fee WHERE student_reg_no = '$reg_no'");

    // Now delete student
    $sql = "DELETE FROM student WHERE reg_no = '$reg_no'";

    if ($conn->query($sql) === TRUE) {
        echo "Student and related records deleted successfully!";
        header('Location: view_student.php');
        exit();
    } else {
        echo "Error deleting student: " . $conn->error;
    }
} else {
    echo "No student selected!";
}
?>
