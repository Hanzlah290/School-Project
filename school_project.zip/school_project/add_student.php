<?php
include 'db_connect.php';

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get student data
    $reg_no = $_POST['reg_no'];
    $name = $_POST['name'];
    $father_name = $_POST['father_name'];
    $student_cnic = $_POST['student_cnic'];
    $address = $_POST['address'];

    // Get parent data
    $parent_cnic = $_POST['parent_cnic'];
    $father_occupation = $_POST['father_occupation'];
    $phone_number = $_POST['phone_number'];

    // Step 1: Insert parent if not exists
    $check = $conn->prepare("SELECT * FROM parent WHERE cnic = ?");
    $check->bind_param("s", $parent_cnic);
    $check->execute();
    $check_result = $check->get_result();

    if ($check_result->num_rows == 0) {
        $insert_parent = $conn->prepare("INSERT INTO parent (cnic, father_occupation, phone_number) VALUES (?, ?, ?)");
        $insert_parent->bind_param("sss", $parent_cnic, $father_occupation, $phone_number);
        $insert_parent->execute();
    }

    // Step 2: Insert student
    $insert_student = $conn->prepare("INSERT INTO student (reg_no, name, father_name, cnic, address, parent_cnic) VALUES (?, ?, ?, ?, ?, ?)");
    $insert_student->bind_param("isssss", $reg_no, $name, $father_name, $student_cnic, $address, $parent_cnic);

    if ($insert_student->execute()) {
        $message = "Student and parent saved successfully!";
    } else {
        $message = "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Student & Parent</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef2f3;
            text-align: center;
        }

        form {
            background-color: white;
            width: 60%;
            margin: auto;
            padding: 20px;
            margin-top: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px gray;
        }

        input {
            width: 90%;
            padding: 8px;
            margin: 10px 0;
        }

        button {
            padding: 10px 25px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
        }

        button:hover {
            background-color: #45a049;
        }

        .success {
            color: green;
            font-weight: bold;
        }

        .error {
            color: red;
            font-weight: bold;
        }

        a.back {
            display: inline-block;
            margin-top: 20px;
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
        }

        a.back:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<h2>Add New Student & Parent</h2>

<?php if ($message): ?>
    <p class="<?= strpos($message, 'success') !== false ? 'success' : 'error' ?>"><?= $message ?></p>
<?php endif; ?>

<form method="POST" action="add_student.php">
    <h3>Student Information</h3>
    <input type="number" name="reg_no" placeholder="Registration Number" required><br>
    <input type="text" name="name" placeholder="Student Name" required><br>
    <input type="text" name="father_name" placeholder="Father Name"><br>
    <input type="text" name="student_cnic" placeholder="Student CNIC"><br>
    <input type="text" name="address" placeholder="Address"><br>

    <h3>Parent Information</h3>
    <input type="text" name="parent_cnic" placeholder="Parent CNIC" required><br>
    <input type="text" name="father_occupation" placeholder="Father Occupation"><br>
    <input type="text" name="phone_number" placeholder="Phone Number"><br>

    <button type="submit">Add Student</button>
</form>

<a href="index.php" class="back">← Back to Home</a>

</body>
</html>
