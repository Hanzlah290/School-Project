<?php
include 'db_connect.php';

$message = '';

if (isset($_GET['attendance_id'])) {
    $attendance_id = $_GET['attendance_id'];

    // Fetch current attendance record
    $res = $conn->query("SELECT * FROM attendance WHERE attendance_id = $attendance_id");
    $row = $res->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $attendance_id = $_POST['attendance_id'];
    $student_reg_no = $_POST['student_reg_no'];
    $teacher_id = $_POST['teacher_id'];
    $date = $_POST['date'];
    $status = $_POST['status'];

    $sql = "UPDATE attendance 
            SET date = '$date',
                status = '$status',
                student_reg_no = '$student_reg_no',
                teacher_id = '$teacher_id'
            WHERE attendance_id = $attendance_id";

    if ($conn->query($sql) === TRUE) {
        $message = "Attendance updated successfully!";
        $res = $conn->query("SELECT * FROM attendance WHERE attendance_id = $attendance_id");
        $row = $res->fetch_assoc(); // Reload updated data
    } else {
        $message = "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Attendance</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef2f3;
            text-align: center;
        }

        form {
            background-color: #fff;
            width: 60%;
            margin: auto;
            padding: 20px;
            margin-top: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px gray;
        }

        input, select {
            width: 90%;
            padding: 8px;
            margin: 10px 0;
        }

        button {
            padding: 10px 25px;
            background-color: #ffc107;
            color: white;
            border: none;
            border-radius: 5px;
        }

        button:hover {
            background-color: #e0a800;
        }

        a.back {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
        }

        .success {
            color: green;
            font-weight: bold;
        }

        .error {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>Edit Attendance</h2>

<?php if ($message): ?>
    <p class="<?= strpos($message, 'successfully') !== false ? 'success' : 'error' ?>"><?= $message ?></p>
<?php endif; ?>

<form method="POST" action="edit_attendance.php">
    <input type="hidden" name="attendance_id" value="<?= $row['attendance_id'] ?>">

    <label>Select Student:</label><br>
    <select name="student_reg_no" required>
        <?php
        $students = $conn->query("SELECT * FROM student");
        while ($s = $students->fetch_assoc()) {
            $selected = $s['reg_no'] == $row['student_reg_no'] ? 'selected' : '';
            echo "<option value='{$s['reg_no']}' $selected>{$s['reg_no']} - {$s['name']}</option>";
        }
        ?>
    </select><br>

    <label>Select Teacher:</label><br>
    <select name="teacher_id" required>
        <?php
        $teachers = $conn->query("SELECT * FROM teacher");
        while ($t = $teachers->fetch_assoc()) {
            $selected = $t['teacher_id'] == $row['teacher_id'] ? 'selected' : '';
            echo "<option value='{$t['teacher_id']}' $selected>{$t['name']}</option>";
        }
        ?>
    </select><br>

    <label>Date:</label><br>
    <input type="date" name="date" value="<?= $row['date'] ?>" required><br>

    <label>Status:</label><br>
    <select name="status" required>
        <option value="Present" <?= $row['status'] == 'Present' ? 'selected' : '' ?>>Present</option>
        <option value="Absent" <?= $row['status'] == 'Absent' ? 'selected' : '' ?>>Absent</option>
        <option value="Late" <?= $row['status'] == 'Late' ? 'selected' : '' ?>>Late</option>
    </select><br>

    <button type="submit">Update Attendance</button>
</form>

<a href="view_attendance.php" class="back">← Back to Attendance</a>

</body>
</html>
