<?php
include 'db_connect.php';

$message = '';

if (isset($_GET['voucher_no'])) {
    $voucher_no = $_GET['voucher_no'];

    // Fetch existing record
    $res = $conn->query("SELECT * FROM fee WHERE voucher_no = $voucher_no");
    $row = $res->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $voucher_no = $_POST['voucher_no'];
    $student_reg_no = $_POST['student_reg_no'];
    $total_fee = $_POST['total_fee'];
    $pending_fee = $_POST['pending_fee'];
    $date = $_POST['date'];

    $sql = "UPDATE fee 
            SET student_reg_no = '$student_reg_no',
                total_fee = '$total_fee',
                pending_fee = '$pending_fee',
                date = '$date'
            WHERE voucher_no = $voucher_no";

    if ($conn->query($sql) === TRUE) {
        $message = "Fee record updated successfully!";
        // Reload updated values
        $res = $conn->query("SELECT * FROM fee WHERE voucher_no = $voucher_no");
        $row = $res->fetch_assoc();
    } else {
        $message = "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Fee Record</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            text-align: center;
        }

        form {
            background-color: #fff;
            width: 60%;
            margin: auto;
            padding: 20px;
            margin-top: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px gray;
        }

        input, select {
            width: 90%;
            padding: 8px;
            margin: 10px 0;
        }

        button {
            padding: 10px 25px;
            background-color: #ffc107;
            color: white;
            border: none;
            border-radius: 5px;
        }

        button:hover {
            background-color: #e0a800;
        }

        a.back {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
        }

        .success {
            color: green;
            font-weight: bold;
        }

        .error {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>Edit Fee Record</h2>

<?php if ($message): ?>
    <p class="<?= strpos($message, 'successfully') !== false ? 'success' : 'error' ?>"><?= $message ?></p>
<?php endif; ?>

<form method="POST" action="edit_fee.php">
    <input type="hidden" name="voucher_no" value="<?= $row['voucher_no'] ?>">

    <label>Select Student:</label><br>
    <select name="student_reg_no" required>
        <?php
        $students = $conn->query("SELECT * FROM student");
        while ($s = $students->fetch_assoc()) {
            $selected = $s['reg_no'] == $row['student_reg_no'] ? 'selected' : '';
            echo "<option value='{$s['reg_no']}' $selected>{$s['reg_no']} - {$s['name']}</option>";
        }
        ?>
    </select><br>

    <label>Total Fee:</label><br>
    <input type="number" name="total_fee" value="<?= $row['total_fee'] ?>" required><br>

    <label>Pending Fee:</label><br>
    <input type="number" name="pending_fee" value="<?= $row['pending_fee'] ?>" required><br>

    <label>Date:</label><br>
    <input type="date" name="date" value="<?= $row['date'] ?>" required><br>

    <button type="submit">Update Fee</button>
</form>

<a href="view_fee.php" class="back">← Back to Fee Records</a>

</body>
</html>
