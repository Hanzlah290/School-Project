<?php include 'db_connect.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>View Teachers</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef1f4;
            text-align: center;
        }

        h2 {
            margin-top: 30px;
        }

        table {
            width: 90%;
            margin: 30px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 0 10px #aaa;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ccc;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:hover {
            background-color: #f2f2f2;
        }

        a.back {
            display: inline-block;
            margin-top: 20px;
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
        }

        a.back:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<h2>Teachers List</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Subject</th>
        <th>Phone</th>
        <th>Email</th>
    </tr>

<?php
$result = $conn->query("SELECT * FROM teacher");

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['teacher_id']}</td>
                <td>{$row['name']}</td>
                <td>{$row['subject']}</td>
                <td>{$row['phone_no']}</td>
                <td>{$row['email']}</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='5'>No teachers found.</td></tr>";
}
?>

</table>

<a href="index.php" class="back">← Back to Home</a>

</body>
</html>
