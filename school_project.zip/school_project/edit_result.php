<?php
include 'db_connect.php';

$message = '';

if (isset($_GET['result_id'])) {
    $result_id = $_GET['result_id'];

    // Fetch existing result
    $sql = "SELECT * FROM results WHERE result_id = $result_id";
    $res = $conn->query($sql);
    $row = $res->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $result_id = $_POST['result_id'];
    $student_reg_no = $_POST['student_reg_no'];
    $teacher_id = $_POST['teacher_id'];
    $subject_name = $_POST['subject_name'];
    $max_marks = $_POST['max_marks'];
    $marks_obtained = $_POST['marks_obtained'];
    $total_marks = $_POST['total_marks'];
    $percentage = ($marks_obtained / $max_marks) * 100;
    $remarks = $_POST['remarks'];

    $update = "UPDATE results SET 
                subject_name='$subject_name',
                max_marks='$max_marks',
                marks_obtained='$marks_obtained',
                total_marks='$total_marks',
                max_percentage='$percentage',
                remarks='$remarks',
                student_reg_no='$student_reg_no',
                teacher_id='$teacher_id'
               WHERE result_id = $result_id";

    if ($conn->query($update) === TRUE) {
        $message = "Result updated successfully!";
        // Reload updated values
        $res = $conn->query("SELECT * FROM results WHERE result_id = $result_id");
        $row = $res->fetch_assoc();
    } else {
        $message = "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef2f3;
            text-align: center;
        }

        form {
            background-color: #fff;
            width: 60%;
            margin: auto;
            padding: 20px;
            margin-top: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px gray;
        }

        input, select, textarea {
            width: 90%;
            padding: 8px;
            margin: 10px 0;
        }

        button {
            padding: 10px 25px;
            background-color: #ffc107;
            color: white;
            border: none;
            border-radius: 5px;
        }

        button:hover {
            background-color: #e0a800;
        }

        a.back {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
        }

        .success {
            color: green;
            font-weight: bold;
        }

        .error {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>Edit Result</h2>

<?php if ($message): ?>
    <p class="<?= strpos($message, 'successfully') !== false ? 'success' : 'error' ?>"><?= $message ?></p>
<?php endif; ?>

<form method="POST" action="edit_result.php">
    <input type="hidden" name="result_id" value="<?= $row['result_id'] ?>">

    <label>Select Student:</label><br>
    <select name="student_reg_no" required>
        <option value="">--Select Student--</option>
        <?php
        $students = $conn->query("SELECT * FROM student");
        while ($s = $students->fetch_assoc()) {
            $selected = $s['reg_no'] == $row['student_reg_no'] ? 'selected' : '';
            echo "<option value='{$s['reg_no']}' $selected>{$s['reg_no']} - {$s['name']}</option>";
        }
        ?>
    </select><br>

    <label>Select Teacher:</label><br>
    <select name="teacher_id" required>
        <option value="">--Select Teacher--</option>
        <?php
        $teachers = $conn->query("SELECT * FROM teacher");
        while ($t = $teachers->fetch_assoc()) {
            $selected = $t['teacher_id'] == $row['teacher_id'] ? 'selected' : '';
            echo "<option value='{$t['teacher_id']}' $selected>{$t['name']}</option>";
        }
        ?>
    </select><br>

    <input type="text" name="subject_name" placeholder="Subject Name" value="<?= $row['subject_name'] ?>" required><br>
    <input type="number" name="max_marks" placeholder="Max Marks" value="<?= $row['max_marks'] ?>" required><br>
    <input type="number" name="marks_obtained" placeholder="Marks Obtained" value="<?= $row['marks_obtained'] ?>" required><br>
    <input type="number" name="total_marks" placeholder="Total Marks" value="<?= $row['total_marks'] ?>" required><br>
    <textarea name="remarks" placeholder="Remarks"><?= $row['remarks'] ?></textarea><br>

    <button type="submit">Update Result</button>
</form>

<a href="view_results.php" class="back">← Back to Results</a>

</body>
</html>
