<?php include 'db_connect.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>View Fee Records</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            text-align: center;
        }

        h2 {
            margin-top: 30px;
        }

        table {
            width: 90%;
            margin: 30px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 0 10px #aaa;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
        }

        th {
            background-color: #28a745;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        a.back {
            display: inline-block;
            margin-top: 20px;
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
        }

        a.back:hover {
            background-color: #218838;
        }

        .action-btn {
            margin: 0 5px;
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 14px;
        }

        .edit {
            background-color: #ffc107;
            color: white;
        }

        .delete {
            background-color: #dc3545;
            color: white;
        }

        .edit:hover {
            background-color: #e0a800;
        }

        .delete:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>

<h2>Student Fee Records</h2>

<table>
    <tr>
        <th>Voucher No</th>
        <th>Student Reg No</th>
        <th>Student Name</th>
        <th>Total Fee</th>
        <th>Pending Fee</th>
        <th>Date</th>
        <th>Actions</th>
    </tr>

<?php
$sql = "SELECT f.*, s.name AS student_name 
        FROM fee f 
        JOIN student s ON f.student_reg_no = s.reg_no";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['voucher_no']}</td>
                <td>{$row['student_reg_no']}</td>
                <td>{$row['student_name']}</td>
                <td>Rs. {$row['total_fee']}</td>
                <td>Rs. {$row['pending_fee']}</td>
                <td>{$row['date']}</td>
                <td>
                    <a class='action-btn edit' href='edit_fee.php?voucher_no={$row['voucher_no']}'>Edit</a>
                    <a class='action-btn delete' href='delete_fee.php?voucher_no={$row['voucher_no']}' onclick=\"return confirm('Are you sure you want to delete this fee record?')\">Delete</a>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='7'>No fee records found.</td></tr>";
}
?>

</table>

<a href="index.php" class="back">← Back to Home</a>

</body>
</html>
