<?php include 'db_connect.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Students</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 40px 0;
            text-align: center;
            color: #333;
        }

        h2 {
            color: #4CAF50;
            margin-bottom: 30px;
        }

        table {
            width: 90%;
            margin: 0 auto;
            border-collapse: collapse;
            background-color: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 14px 16px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:hover {
            background-color: #f9f9f9;
        }

        .toggle-btn {
            cursor: pointer;
            color: #4CAF50;
            font-weight: bold;
        }

        tr.detail-row {
            display: none;
            background-color: #fafafa;
        }

        .actions a {
            text-decoration: none;
            color: #007BFF;
            margin: 0 5px;
        }

        .actions a:hover {
            text-decoration: underline;
        }

        .back-link {
            display: inline-block;
            margin-top: 30px;
            text-decoration: none;
            color: #4CAF50;
            font-weight: bold;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
    <script>
        function toggleDetails(rowId) {
            var row = document.getElementById(rowId);
            row.style.display = (row.style.display === "table-row") ? "none" : "table-row";
        }
    </script>
</head>
<body>

<h2>Students List</h2>

<table>
    <tr>
        <th>Reg No</th>
        <th>Name</th>
        <th>Father Name</th>
        <th>Address</th>
        <th>Parent Info</th>
        <th>Actions</th>
    </tr>

<?php
$sql = "SELECT * FROM student";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $reg_no = $row['reg_no'];
        $parent_cnic = $row['parent_cnic'];
        $parent_sql = "SELECT * FROM parent WHERE cnic = '$parent_cnic'";
        $parent_result = $conn->query($parent_sql);
        $parent = $parent_result->fetch_assoc();

        echo "<tr>
                <td>{$row['reg_no']}</td>
                <td>{$row['name']}</td>
                <td>{$row['father_name']}</td>
                <td>{$row['address']}</td>
                <td><span class='toggle-btn' onclick=\"toggleDetails('p{$reg_no}')\">▼ View</span></td>
                <td class='actions'>
                    <a href='edit_student.php?reg_no={$row['reg_no']}'>Edit</a> |
                    <a href='delete_student.php?reg_no={$row['reg_no']}'>Delete</a>
                </td>
              </tr>";

        echo "<tr id='p{$reg_no}' class='detail-row'>
                <td colspan='6'>
                    <strong>Parent CNIC:</strong> {$parent['cnic']}<br>
                    <strong>Occupation:</strong> {$parent['father_occupation']}<br>
                    <strong>Phone:</strong> {$parent['phone_number']}
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='6'>No students found.</td></tr>";
}
?>

</table>

<a class="back-link" href="index.php">← Back to Home</a>

</body>
</html>
