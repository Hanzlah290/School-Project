<?php include 'db_connect.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>View Teachers</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef2f3;
            text-align: center;
        }

        h2 {
            margin-top: 30px;
        }

        table {
            width: 90%;
            margin: 30px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 0 10px #aaa;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
        }

        th {
            background-color: #17a2b8;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .action-btn {
            margin: 0 5px;
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 14px;
        }

        .edit {
            background-color: #ffc107;
            color: white;
        }

        .delete {
            background-color: #dc3545;
            color: white;
        }

        .edit:hover {
            background-color: #e0a800;
        }

        .delete:hover {
            background-color: #c82333;
        }

        a.back {
            display: inline-block;
            margin-top: 20px;
            background-color: #17a2b8;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
        }

        a.back:hover {
            background-color: #138496;
        }
    </style>
</head>
<body>

<h2>Teacher List</h2>

<table>
    <tr>
        <th>Teacher ID</th>
        <th>Name</th>
        <th>Subject</th>
        <th>Phone</th>
        <th>Email</th>
        <th>Actions</th>
    </tr>

<?php
$sql = "SELECT * FROM teacher";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['teacher_id']}</td>
                <td>{$row['name']}</td>
                <td>{$row['subject']}</td>
                <td>{$row['phone_no']}</td>
                <td>{$row['email']}</td>
                <td>
                    <a class='action-btn edit' href='edit_teacher.php?teacher_id={$row['teacher_id']}'>Edit</a>
                    <a class='action-btn delete' href='delete_teacher.php?teacher_id={$row['teacher_id']}' onclick=\"return confirm('Are you sure you want to delete this teacher?')\">Delete</a>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='6'>No teachers found.</td></tr>";
}
?>

</table>

<a href="index.php" class="back">← Back to Home</a>

</body>
</html>
