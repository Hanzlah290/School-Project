<?php
include 'db_connect.php';

$message = '';

if (isset($_GET['teacher_id'])) {
    $teacher_id = $_GET['teacher_id'];

    // Fetch existing teacher
    $res = $conn->query("SELECT * FROM teacher WHERE teacher_id = $teacher_id");
    if ($res->num_rows === 1) {
        $row = $res->fetch_assoc();
    } else {
        $message = "Teacher not found!";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $teacher_id = $_POST['teacher_id'];
    $name = $_POST['name'];
    $subject = $_POST['subject'];
    $phone_no = $_POST['phone_no'];
    $email = $_POST['email'];

    $sql = "UPDATE teacher SET name=?, subject=?, phone_no=?, email=? WHERE teacher_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $name, $subject, $phone_no, $email, $teacher_id);

    if ($stmt->execute()) {
        header("Location: view_teacher.php?msg=updated");
        exit();
    } else {
        $message = "Error updating: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Teacher</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef2f3;
            text-align: center;
        }

        form {
            background-color: white;
            width: 50%;
            margin: auto;
            padding: 20px;
            margin-top: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px gray;
        }

        input {
            width: 90%;
            padding: 8px;
            margin: 10px 0;
        }

        button {
            padding: 10px 25px;
            background-color: #ffc107;
            color: white;
            border: none;
            border-radius: 5px;
        }

        button:hover {
            background-color: #e0a800;
        }

        .error {
            color: red;
            font-weight: bold;
        }

        a.back {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<h2>Edit Teacher</h2>

<?php if ($message): ?>
    <p class="error"><?= $message ?></p>
<?php endif; ?>

<?php if (isset($row)) { ?>
<form method="POST" action="edit_teacher.php">
    <input type="hidden" name="teacher_id" value="<?= $row['teacher_id'] ?>">

    <input type="text" name="name" value="<?= $row['name'] ?>" placeholder="Full Name" required><br>
    <input type="text" name="subject" value="<?= $row['subject'] ?>" placeholder="Subject" required><br>
    <input type="text" name="phone_no" value="<?= $row['phone_no'] ?>" placeholder="Phone Number"><br>
    <input type="email" name="email" value="<?= $row['email'] ?>" placeholder="Email" required><br>

    <button type="submit">Update Teacher</button>
</form>
<?php } ?>

<a href="view_teacher.php" class="back">← Back to List</a>

</body>
</html>
