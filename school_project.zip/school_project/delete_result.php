<?php
include 'db_connect.php';

if (isset($_GET['result_id'])) {
    $result_id = $_GET['result_id'];

    $sql = "DELETE FROM results WHERE result_id = $result_id";

    if ($conn->query($sql) === TRUE) {
        header("Location: view_results.php?msg=deleted");
        exit();
    } else {
        echo "Error deleting result: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}
?>
