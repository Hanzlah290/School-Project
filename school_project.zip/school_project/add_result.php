<?php
include 'db_connect.php';

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_reg_no = $_POST['student_reg_no'];
    $teacher_id = $_POST['teacher_id'];
    $subject_name = $_POST['subject_name'];
    $max_marks = $_POST['max_marks'];
    $marks_obtained = $_POST['marks_obtained'];
    $total_marks = $_POST['total_marks'];
    $percentage = ($marks_obtained / $max_marks) * 100;
    $remarks = $_POST['remarks'];

    $sql = "INSERT INTO results (subject_name, max_marks, marks_obtained, total_marks, max_percentage, remarks, student_reg_no, teacher_id) 
            VALUES ('$subject_name', '$max_marks', '$marks_obtained', '$total_marks', '$percentage', '$remarks', '$student_reg_no', '$teacher_id')";

    if ($conn->query($sql) === TRUE) {
        $message = "Result added successfully!";
    } else {
        $message = "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef2f3;
            text-align: center;
        }

        form {
            background-color: #fff;
            width: 60%;
            margin: auto;
            padding: 20px;
            margin-top: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px gray;
        }

        input, select, textarea {
            width: 90%;
            padding: 8px;
            margin: 10px 0;
        }

        button {
            padding: 10px 25px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
        }

        button:hover {
            background-color: #0056b3;
        }

        a.back {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
        }

        .success {
            color: green;
            font-weight: bold;
        }

        .error {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>Add Result</h2>

<?php if ($message): ?>
    <p class="<?= strpos($message, 'successfully') !== false ? 'success' : 'error' ?>"><?= $message ?></p>
<?php endif; ?>

<form method="POST" action="add_result.php">
    <label>Select Student:</label><br>
    <select name="student_reg_no" required>
        <option value="">--Select Student--</option>
        <?php
        $students = $conn->query("SELECT * FROM student");
        while ($s = $students->fetch_assoc()) {
            echo "<option value='{$s['reg_no']}'>{$s['reg_no']} - {$s['name']}</option>";
        }
        ?>
    </select><br>

    <label>Select Teacher:</label><br>
    <select name="teacher_id" required>
        <option value="">--Select Teacher--</option>
        <?php
        $teachers = $conn->query("SELECT * FROM teacher");
        while ($t = $teachers->fetch_assoc()) {
            echo "<option value='{$t['teacher_id']}'>{$t['name']}</option>";
        }
        ?>
    </select><br>

    <input type="text" name="subject_name" placeholder="Subject Name" required><br>
    <input type="number" name="max_marks" placeholder="Max Marks" required><br>
    <input type="number" name="marks_obtained" placeholder="Marks Obtained" required><br>
    <input type="number" name="total_marks" placeholder="Total Marks" required><br>
    <textarea name="remarks" placeholder="Remarks (optional)"></textarea><br>

    <button type="submit">Add Result</button>
</form>

<a href="index.php" class="back">← Back to Home</a>

</body>
</html>
