<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Management System</title>
    <style>
        /* Global Styles */
        body {
            background-color: #f0f0f0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }

        /* Main Container */
        .container {
            text-align: center;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
        }

        /* Heading Styles */
        h1 {
            color: #4CAF50;
            font-size: 2.5em;
            margin-bottom: 20px;
        }

        /* Navigation Styles */
        ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        li {
            margin: 15px 0;
        }

        a {
            text-decoration: none;
            display: inline-block;
            background-color: #4CAF50;
            color: white;
            padding: 12px 25px;
            border-radius: 5px;
            font-size: 1.1em;
            width: 200px;
            transition: all 0.3s ease;
        }

        a:hover {
            background-color: #45a049;
            transform: translateY(-3px);
        }

        /* Responsive Design */
        @media screen and (max-width: 600px) {
            h1 {
                font-size: 2em;
            }

            a {
                width: 150px;
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Welcome to the School Management System</h1>

        <ul>
    <li><a href="add_student.php">Add Student</a></li>
    <li><a href="view_student.php">View Students</a></li>

    <li>
        <a href="javascript:void(0);" onclick="toggleMenu('resultMenu')">Results ▼</a>
        <ul id="resultMenu" style="display:none; list-style-type: none; padding-left: 20px;">
            <li><a href="add_result.php">Add Result</a></li>
            <li><a href="view_results.php">View Results</a></li>
        </ul>
    </li>

    <li>
        <a href="javascript:void(0);" onclick="toggleMenu('teacherMenu')">Teachers ▼</a>
        <ul id="teacherMenu" style="display:none; list-style-type: none; padding-left: 20px;">
            <li><a href="view_teachers.php">View Teachers</a></li>
        </ul>
    </li>

    <li>
        <a href="javascript:void(0);" onclick="toggleMenu('attendanceMenu')">Attendance ▼</a>
        <ul id="attendanceMenu" style="display:none; list-style-type: none; padding-left: 20px;">
            <li><a href="view_attendance.php">View Attendance</a></li>
            <li><a href="add_attendance.php">Add Attendance</a></li>

        </ul>
    </li>

    <li>
        <a href="javascript:void(0);" onclick="toggleMenu('feeMenu')">Fee ▼</a>
        <ul id="feeMenu" style="display:none; list-style-type: none; padding-left: 20px;">
            <li><a href="view_fee.php">View Fee Records</a></li>
            <li><a href="add_fee.php">Add Fee</a></li>

        </ul>
    </li>
</ul>

    </div>
    <script>
function toggleMenu(id) {
    var menu = document.getElementById(id);
    menu.style.display = (menu.style.display === "none") ? "block" : "none";
}
</script>


</body>
</html>
