<?php
include 'db_connect.php';

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_reg_no = $_POST['student_reg_no'];
    $teacher_id = $_POST['teacher_id'];
    $date = $_POST['date'];
    $status = $_POST['status'];

    $sql = "INSERT INTO attendance (date, status, student_reg_no, teacher_id)
            VALUES ('$date', '$status', '$student_reg_no', '$teacher_id')";

    if ($conn->query($sql) === TRUE) {
        $message = "Attendance marked successfully!";
    } else {
        $message = "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Attendance</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef2f3;
            text-align: center;
        }

        form {
            background-color: #fff;
            width: 60%;
            margin: auto;
            padding: 20px;
            margin-top: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px gray;
        }

        input, select {
            width: 90%;
            padding: 8px;
            margin: 10px 0;
        }

        button {
            padding: 10px 25px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
        }

        button:hover {
            background-color: #218838;
        }

        a.back {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
        }

        .success {
            color: green;
            font-weight: bold;
        }

        .error {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>Mark Attendance</h2>

<?php if ($message): ?>
    <p class="<?= strpos($message, 'successfully') !== false ? 'success' : 'error' ?>"><?= $message ?></p>
<?php endif; ?>

<form method="POST" action="add_attendance.php">
    <label>Select Student:</label><br>
    <select name="student_reg_no" required>
        <option value="">--Select Student--</option>
        <?php
        $students = $conn->query("SELECT * FROM student");
        while ($s = $students->fetch_assoc()) {
            echo "<option value='{$s['reg_no']}'>{$s['reg_no']} - {$s['name']}</option>";
        }
        ?>
    </select><br>

    <label>Select Teacher:</label><br>
    <select name="teacher_id" required>
        <option value="">--Select Teacher--</option>
        <?php
        $teachers = $conn->query("SELECT * FROM teacher");
        while ($t = $teachers->fetch_assoc()) {
            echo "<option value='{$t['teacher_id']}'>{$t['name']}</option>";
        }
        ?>
    </select><br>

    <label>Date:</label><br>
    <input type="date" name="date" required><br>

    <label>Status:</label><br>
    <select name="status" required>
        <option value="">--Select Status--</option>
        <option value="Present">Present</option>
        <option value="Absent">Absent</option>
        <option value="Late">Late</option>
    </select><br>

    <button type="submit">Mark Attendance</button>
</form>

<a href="index.php" class="back">← Back to Home</a>

</body>
</html>
