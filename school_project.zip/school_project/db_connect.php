<?php
$servername = "localhost";
$username = "root";   // default user
$password = "";       // default no password
$database = "project"; // your database name

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
