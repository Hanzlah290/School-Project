<?php
include 'db_connect.php';

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $voucher_no = $_POST['voucher_no'];
    $student_reg_no = $_POST['student_reg_no'];
    $total_fee = $_POST['total_fee'];
    $pending_fee = $_POST['pending_fee'];
    $date = $_POST['date'];

    $sql = "INSERT INTO fee (voucher_no, student_reg_no, total_fee, pending_fee, date)
            VALUES ('$voucher_no', '$student_reg_no', '$total_fee', '$pending_fee', '$date')";

    if ($conn->query($sql) === TRUE) {
        $message = "Fee record added successfully!";
    } else {
        $message = "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Fee Record</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            text-align: center;
        }

        form {
            background-color: #fff;
            width: 60%;
            margin: auto;
            padding: 20px;
            margin-top: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px gray;
        }

        input, select {
            width: 90%;
            padding: 8px;
            margin: 10px 0;
        }

        button {
            padding: 10px 25px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
        }

        button:hover {
            background-color: #218838;
        }

        a.back {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
        }

        .success {
            color: green;
            font-weight: bold;
        }

        .error {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>Add Fee Record</h2>

<?php if ($message): ?>
    <p class="<?= strpos($message, 'successfully') !== false ? 'success' : 'error' ?>"><?= $message ?></p>
<?php endif; ?>

<form method="POST" action="add_fee.php">
    <label>Voucher No:</label><br>
    <input type="number" name="voucher_no" required><br>

    <label>Select Student:</label><br>
    <select name="student_reg_no" required>
        <option value="">--Select Student--</option>
        <?php
        $students = $conn->query("SELECT * FROM student");
        while ($s = $students->fetch_assoc()) {
            echo "<option value='{$s['reg_no']}'>{$s['reg_no']} - {$s['name']}</option>";
        }
        ?>
    </select><br>

    <label>Total Fee:</label><br>
    <input type="number" name="total_fee" required><br>

    <label>Pending Fee:</label><br>
    <input type="number" name="pending_fee" required><br>

    <label>Date:</label><br>
    <input type="date" name="date" required><br>

    <button type="submit">Add Fee</button>
</form>

<a href="index.php" class="back">← Back to Home</a>

</body>
</html>
