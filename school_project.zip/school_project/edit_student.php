<?php 
include 'db_connect.php'; 
session_start();

$message = '';
$reg_no = null;

// Step 1: Fetch student data
if (isset($_GET['reg_no'])) {
    $reg_no = $_GET['reg_no'];

    $stmt = $conn->prepare("SELECT * FROM student WHERE reg_no = ?");
    $stmt->bind_param("s", $reg_no);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
    } else {
        $error = "Student not found!";
    }
} else {
    $error = "No student selected!";
}

// Step 2: Update logic
if (isset($_POST['update'])) {
    $new_name = $_POST['name'];
    $new_father_name = $_POST['father_name'];
    $new_cnic = $_POST['cnic'];
    $new_address = $_POST['address'];
    $new_parent_cnic = $_POST['parent_cnic'];

    $stmt = $conn->prepare("UPDATE student SET name=?, father_name=?, cnic=?, address=?, parent_cnic=? WHERE reg_no=?");
    $stmt->bind_param("ssssss", $new_name, $new_father_name, $new_cnic, $new_address, $new_parent_cnic, $reg_no);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Student updated successfully!";
        header("Location: view_student.php");
        exit();
    } else {
        $error = "Error updating student: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
    <style>
        body {
            background-color: #f2f2f2;
            font-family: Arial, sans-serif;
            text-align: center;
        }
        .form-container {
            background-color: white;
            margin-top: 50px;
            padding: 30px;
            display: inline-block;
            border-radius: 10px;
            box-shadow: 0 0 10px gray;
            width: 400px;
        }
        input[type=text], input[type=submit] {
            padding: 10px;
            margin: 10px 0;
            width: 90%;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[type=submit] {
            background-color: #4CAF50;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }
        input[type=submit]:hover {
            background-color: #45a049;
        }
        .back-link {
            margin-top: 20px;
            display: inline-block;
            color:rgb(0, 0, 0);
            text-decoration: none;
            font-weight: bold;
        }
        .message {
            margin-top: 20px;
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>Edit Student</h2>

<?php if (isset($error)) echo "<div class='message'>$error</div>"; ?>
<?php if (isset($message)) echo "<div class='message' style='color: green;'>$message</div>"; ?>

<?php if (isset($row)) { ?>
    <div class="form-container">
        <form action="edit_student.php?reg_no=<?php echo $reg_no; ?>" method="POST">
            <input type="text" name="name" placeholder="Name" value="<?php echo htmlspecialchars($row['name']); ?>" required><br>
            <input type="text" name="father_name" placeholder="Father Name" value="<?php echo htmlspecialchars($row['father_name']); ?>"><br>
            <input type="text" name="cnic" placeholder="CNIC" value="<?php echo htmlspecialchars($row['cnic']); ?>"><br>
            <input type="text" name="address" placeholder="Address" value="<?php echo htmlspecialchars($row['address']); ?>"><br>
            <input type="text" name="parent_cnic" placeholder="Parent CNIC" value="<?php echo htmlspecialchars($row['parent_cnic']); ?>" required><br>
            
            <input type="submit" name="update" value="Update Student">
        </form>
        <a class="back-link" href="view_student.php">← Back to List</a>
    </div>
<?php } ?>

</body>
</html>
