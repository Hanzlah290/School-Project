<?php include 'db_connect.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>View Attendance</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef3f7;
            text-align: center;
        }

        h2 {
            margin-top: 30px;
        }

        table {
            width: 95%;
            margin: 30px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 0 10px #aaa;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
        }

        th {
            background-color: #ff9800;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        a.back {
            display: inline-block;
            margin-top: 20px;
            background-color: #ff9800;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
        }

        a.back:hover {
            background-color: #e08e00;
        }

        .action-btn {
            margin: 0 5px;
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 14px;
        }

        .edit {
            background-color: #ffc107;
            color: white;
        }

        .delete {
            background-color: #dc3545;
            color: white;
        }

        .edit:hover {
            background-color: #e0a800;
        }

        .delete:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>

<h2>Student Attendance Records</h2>

<table>
    <tr>
        <th>Attendance ID</th>
        <th>Date</th>
        <th>Status</th>
        <th>Student Reg No</th>
        <th>Student Name</th>
        <th>Teacher</th>
        <th>Actions</th>
    </tr>

<?php
$sql = "SELECT a.*, s.name AS student_name, t.name AS teacher_name 
        FROM attendance a 
        JOIN student s ON a.student_reg_no = s.reg_no 
        JOIN teacher t ON a.teacher_id = t.teacher_id";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['attendance_id']}</td>
                <td>{$row['date']}</td>
                <td>{$row['status']}</td>
                <td>{$row['student_reg_no']}</td>
                <td>{$row['student_name']}</td>
                <td>{$row['teacher_name']}</td>
                <td>
                    <a class='action-btn edit' href='edit_attendance.php?attendance_id={$row['attendance_id']}'>Edit</a>
                    <a class='action-btn delete' href='delete_attendance.php?attendance_id={$row['attendance_id']}' onclick=\"return confirm('Are you sure you want to delete this record?')\">Delete</a>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='7'>No attendance records found.</td></tr>";
}
?>

</table>

<a href="index.php" class="back">← Back to Home</a>

</body>
</html>
