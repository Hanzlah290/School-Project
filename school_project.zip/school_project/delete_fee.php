<?php
include 'db_connect.php';

if (isset($_GET['voucher_no'])) {
    $voucher_no = $_GET['voucher_no'];

    $sql = "DELETE FROM fee WHERE voucher_no = $voucher_no";

    if ($conn->query($sql) === TRUE) {
        header("Location: view_fee.php?msg=deleted");
        exit();
    } else {
        echo "Error deleting fee record: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}
?>
