<?php include 'db_connect.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>View Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f6f6f6;
            text-align: center;
        }

        h2 {
            margin-top: 30px;
        }

        table {
            width: 95%;
            margin: 30px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 0 10px #aaa;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        a.back {
            display: inline-block;
            margin-top: 20px;
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
        }

        a.back:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<h2>Student Results</h2>

<table>
<tr>
    <th>Result ID</th>
    <th>Student Reg No</th>
    <th>Student Name</th>
    <th>Subject</th>
    <th>Marks Obtained</th>
    <th>Max Marks</th>
    <th>Percentage</th>
    <th>Teacher</th>
    <th>Actions</th>
</tr>


<?php
$sql = "SELECT r.*, s.name AS student_name, t.name AS teacher_name 
        FROM results r 
        JOIN student s ON r.student_reg_no = s.reg_no 
        JOIN teacher t ON r.teacher_id = t.teacher_id";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
        <td>{$row['result_id']}</td>
        <td>{$row['student_reg_no']}</td>
        <td>{$row['student_name']}</td>
        <td>{$row['subject_name']}</td>
        <td>{$row['marks_obtained']}</td>
        <td>{$row['max_marks']}</td>
        <td>{$row['max_percentage']}%</td>
        <td>{$row['teacher_name']}</td>
        <td>
            <a href='edit_result.php?result_id={$row['result_id']}' style='color: orange;'>Edit</a> |
            <a href='delete_result.php?result_id={$row['result_id']}' onclick=\"return confirm('Are you sure you want to delete this result?')\" style='color: red;'>Delete</a>
        </td>
      </tr>";

    }
} else {
    echo "<tr><td colspan='8'>No results found.</td></tr>";
}
?>

</table>

<a href="index.php" class="back">← Back to Home</a>

</body>
</html>
