<?php
include 'db_connect.php';

if (isset($_GET['attendance_id'])) {
    $attendance_id = $_GET['attendance_id'];

    $sql = "DELETE FROM attendance WHERE attendance_id = $attendance_id";

    if ($conn->query($sql) === TRUE) {
        header("Location: view_attendance.php?msg=deleted");
        exit();
    } else {
        echo "Error deleting attendance: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}
?>
